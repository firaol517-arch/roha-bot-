import os
import sqlite3
import logging
from datetime import datetime
import google.generativeai as genai
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ContextTypes,
    filters,
)

# ─────────────────────────────────────────────
# Logging
# ─────────────────────────────────────────────
logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────
# Config — ከ Environment variables
# ─────────────────────────────────────────────
TELEGRAM_TOKEN = os.environ.get("TELEGRAM_TOKEN")
GEMINI_API_KEY  = os.environ.get("GEMINI_API_KEY")
ADMIN_IDS       = os.environ.get("ADMIN_IDS", "")   # comma-separated telegram user IDs
DB_PATH         = os.environ.get("DB_PATH", "roha.db")

if not TELEGRAM_TOKEN or not GEMINI_API_KEY:
    raise RuntimeError("TELEGRAM_TOKEN and GEMINI_API_KEY must be set")

# Admin IDs list
ADMIN_LIST = [int(x.strip()) for x in ADMIN_IDS.split(",") if x.strip()]

# Gemini setup
genai.configure(api_key=GEMINI_API_KEY)
gemini_model = genai.GenerativeModel("gemini-1.5-flash")

# ─────────────────────────────────────────────
# Database
# ─────────────────────────────────────────────
def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    # shops table — one row per shop
    c.execute("""
        CREATE TABLE IF NOT EXISTS shops (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            shop_name     TEXT NOT NULL,
            category      TEXT,
            working_hours TEXT,
            delivery_info TEXT,
            payment       TEXT,
            location      TEXT,
            price_list    TEXT,
            extra_info    TEXT,
            created_at    TEXT
        )
    """)

    # messages table — conversation history
    c.execute("""
        CREATE TABLE IF NOT EXISTS messages (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            chat_id    INTEGER NOT NULL,
            shop_id    INTEGER NOT NULL DEFAULT 1,
            role       TEXT NOT NULL,
            content    TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
    """)

    # orders table
    c.execute("""
        CREATE TABLE IF NOT EXISTS orders (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            chat_id       INTEGER NOT NULL,
            shop_id       INTEGER NOT NULL DEFAULT 1,
            customer_name TEXT,
            product       TEXT,
            quantity      TEXT,
            address       TEXT,
            status        TEXT DEFAULT 'pending',
            created_at    TEXT NOT NULL
        )
    """)

    # users table — ደንበኛ መዝገብ
    c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            chat_id    INTEGER PRIMARY KEY,
            username   TEXT,
            full_name  TEXT,
            shop_id    INTEGER DEFAULT 1,
            joined_at  TEXT
        )
    """)

    # Insert demo shop if empty
    c.execute("SELECT COUNT(*) FROM shops")
    if c.fetchone()[0] == 0:
        c.execute("""
            INSERT INTO shops
              (shop_name, category, working_hours, delivery_info, payment, location, price_list, extra_info, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            "ለምለም ቡቲክ",
            "የሴቶች ልብስ እና accessories",
            "ሰኞ-ቅዳሜ ጠዋት 2:30 - ምሽት 12:00",
            "በአዲስ አበባ ውስጥ 24 ሰዓት ማድረሻ | ዋጋ ከ200 ብር ይጀምራል",
            "ቴሌብር | CBE Birr | ባንክ ትራንስፈር",
            "ቦሌ፣ አዲስ አበባ",
            "ቀሚስ: 1200-2500 ብር | ጃኬት: 1800-3000 ብር | ጫማ: 1500-2200 ብር | ቦርሳ: 800-1500 ብር",
            "ሁሉም ምርቶቻችን ከፍተኛ ጥራት ያላቸው ናቸው። ምርቱ ካልተወደደ 3 ቀን ውስጥ መልስ ይቀበላል።",
            datetime.utcnow().isoformat(),
        ))

    conn.commit()
    conn.close()


def get_shop(shop_id: int = 1) -> dict:
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT * FROM shops WHERE id = ?", (shop_id,))
    row = c.fetchone()
    conn.close()
    if not row:
        return {}
    keys = ["id","shop_name","category","working_hours","delivery_info",
            "payment","location","price_list","extra_info","created_at"]
    return dict(zip(keys, row))


def save_message(chat_id: int, role: str, content: str, shop_id: int = 1):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute(
        "INSERT INTO messages (chat_id, shop_id, role, content, created_at) VALUES (?,?,?,?,?)",
        (chat_id, shop_id, role, content, datetime.utcnow().isoformat()),
    )
    conn.commit()
    conn.close()


def get_history(chat_id: int, limit: int = 8) -> list:
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute(
        "SELECT role, content FROM messages WHERE chat_id=? ORDER BY id DESC LIMIT ?",
        (chat_id, limit),
    )
    rows = c.fetchall()
    conn.close()
    rows.reverse()
    return [{"role": r, "content": txt} for r, txt in rows]


def save_user(chat_id: int, username: str, full_name: str, shop_id: int = 1):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""
        INSERT OR IGNORE INTO users (chat_id, username, full_name, shop_id, joined_at)
        VALUES (?, ?, ?, ?, ?)
    """, (chat_id, username, full_name, shop_id, datetime.utcnow().isoformat()))
    conn.commit()
    conn.close()


def save_order(chat_id: int, details: str, shop_id: int = 1):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute(
        "INSERT INTO orders (chat_id, shop_id, product, status, created_at) VALUES (?,?,?,?,?)",
        (chat_id, shop_id, details, "pending", datetime.utcnow().isoformat()),
    )
    conn.commit()
    conn.close()


def get_stats(shop_id: int = 1) -> dict:
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT COUNT(DISTINCT chat_id) FROM messages WHERE shop_id=?", (shop_id,))
    total_users = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM orders WHERE shop_id=?", (shop_id,))
    total_orders = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM orders WHERE shop_id=? AND status='pending'", (shop_id,))
    pending_orders = c.fetchone()[0]
    c.execute("SELECT COUNT(*) FROM messages WHERE shop_id=?", (shop_id,))
    total_messages = c.fetchone()[0]
    conn.close()
    return {
        "total_users": total_users,
        "total_orders": total_orders,
        "pending_orders": pending_orders,
        "total_messages": total_messages,
    }


# ─────────────────────────────────────────────
# System Prompt
# ─────────────────────────────────────────────
def build_system_prompt(shop: dict) -> str:
    return f"""አንተ Roha Bot ነህ - የ{shop['shop_name']} ኦፊሴላዊ AI ረዳት (assistant)።

## ሱቁ ስለሆነ
- ስም: {shop['shop_name']}
- ምርት: {shop['category']}
- የስራ ሰዓት: {shop['working_hours']}
- ማድረሻ: {shop['delivery_info']}
- ክፍያ: {shop['payment']}
- አድራሻ: {shop['location']}
- ዋጋ ዝርዝር: {shop['price_list']}
- ተጨማሪ: {shop.get('extra_info', '')}

## ህጎች
1. ደንበኛ በተናገረበት ቋንቋ (አማርኛ ወይም እንግሊዝኛ) ሁልጊዜ መልስ ስጥ
2. መልስ አጭር፣ ግልጽ እና ጨዋ ይሁን (ከ4 አረፍተ ነገር አይብለጥ)
3. ዋጋ ስለ ሌሎች ምርቶች ሲጠየቅ "ለባለቤቱ አጣራለሁ" በል
4. ትዕዛዝ (order) ሲደረግ: ስም፣ ምርት፣ ብዛት፣ አድራሻ ጠይቅ
5. ተገቢ ያልሆነ ጥያቄ ከተጠየቅህ በትህትና አስቀር
6. ሁልጊዜ emoji ትንሽ ጨምር (🙏 ✅ 📦 💛) ለ friendly ስሜት

## ምሳሌ
ደንበኛ: ቀሚስ ስንት ነው?
አንተ: ቀሚሶቻችን ከ1,200 ብር እስከ 2,500 ብር ይደርሳሉ 💛 ምን አይነት ቀሚስ ትፈልጋለህ/ትፈልጊያለሽ?

ደንበኛ: ማድረሻ ስንት ቀን ይወስዳል?
አንተ: ✅ በአዲስ አበባ ውስጥ በ24 ሰዓት ውስጥ እናደርሳለን!
"""


# ─────────────────────────────────────────────
# Gemini AI Call
# ─────────────────────────────────────────────
def ask_gemini(chat_id: int, user_message: str, shop: dict) -> str:
    try:
        history = get_history(chat_id, limit=8)
        system_prompt = build_system_prompt(shop)

        # Build conversation for Gemini
        chat_history = []
        for msg in history:
            role = "user" if msg["role"] == "user" else "model"
            chat_history.append({"role": role, "parts": [msg["content"]]})

        chat = gemini_model.start_chat(history=chat_history)
        full_message = f"{system_prompt}\n\nደንበኛ: {user_message}"
        response = chat.send_message(full_message)
        return response.text.strip()
    except Exception as e:
        logger.error(f"Gemini error: {e}")
        return "ይቅርታ፣ ትንሽ ችግር ገጥሞኛል። እባክዎ ትንሽ ቆይተው ይሞክሩ 🙏"


# ─────────────────────────────────────────────
# Keyboards
# ─────────────────────────────────────────────
def main_keyboard():
    keyboard = [
        [
            InlineKeyboardButton("📦 ምርቶች", callback_data="products"),
            InlineKeyboardButton("💰 ዋጋ", callback_data="prices"),
        ],
        [
            InlineKeyboardButton("🚚 ማድረሻ", callback_data="delivery"),
            InlineKeyboardButton("💳 ክፍያ", callback_data="payment"),
        ],
        [
            InlineKeyboardButton("🛒 ትዕዛዝ ማድረግ", callback_data="order"),
            InlineKeyboardButton("📍 አድራሻ", callback_data="location"),
        ],
        [
            InlineKeyboardButton("⏰ የስራ ሰዓት", callback_data="hours"),
            InlineKeyboardButton("📞 ያግኙን", callback_data="contact"),
        ],
    ]
    return InlineKeyboardMarkup(keyboard)


def admin_keyboard():
    keyboard = [
        [
            InlineKeyboardButton("📊 Statistics", callback_data="admin_stats"),
            InlineKeyboardButton("📋 Orders", callback_data="admin_orders"),
        ],
        [
            InlineKeyboardButton("✏️ Shop Info አስተካክል", callback_data="admin_edit"),
        ],
    ]
    return InlineKeyboardMarkup(keyboard)


# ─────────────────────────────────────────────
# Telegram Handlers
# ─────────────────────────────────────────────
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    chat_id = update.effective_chat.id
    shop = get_shop(1)

    save_user(chat_id, user.username or "", user.full_name or "")

    welcome = (
        f"ሰላም {user.first_name}! 👋\n\n"
        f"እንኳን ወደ *{shop['shop_name']}* በደህና መጡ 🎉\n\n"
        f"እኔ Roha Bot ነኝ - ስለ ምርቶቻችን፣ ዋጋ፣ ትዕዛዝ እና ማድረሻ ረዳዎ ነኝ 🙏\n\n"
        f"ከታች ካሉት አማራጮች ምረጡ ወይም ቀጥታ ጥያቄዎን ፃፉ 👇"
    )
    await update.message.reply_text(
        welcome,
        parse_mode="Markdown",
        reply_markup=main_keyboard(),
    )


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    user_text = update.message.text
    shop = get_shop(1)

    # Check if order keywords exist
    order_keywords = ["ልዝዝ", "order", "ትዕዛዝ", "እዝዛለሁ", "ልግዛ"]
    is_order = any(kw in user_text.lower() for kw in order_keywords)

    save_message(chat_id, "user", user_text)

    # Typing indicator
    await context.bot.send_chat_action(chat_id=chat_id, action="typing")

    reply = ask_gemini(chat_id, user_text, shop)
    save_message(chat_id, "assistant", reply)

    # If order detected, save to orders
    if is_order:
        save_order(chat_id, user_text)

    await update.message.reply_text(reply, reply_markup=main_keyboard())


async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    chat_id = update.effective_chat.id
    shop = get_shop(1)
    data = query.data

    responses = {
        "products": f"📦 *ምርቶቻችን*\n\n{shop['category']}\n\nየፈለጉትን ምርት ስም ጽፈው ዋጋ ይጠይቁ 👇",
        "prices": f"💰 *ዋጋ ዝርዝር*\n\n{shop['price_list']}\n\nለተጨማሪ ዝርዝር ምርት ስም ጽፈው ይጠይቁ 👇",
        "delivery": f"🚚 *ማድረሻ መረጃ*\n\n{shop['delivery_info']}",
        "payment": f"💳 *የክፍያ መንገዶች*\n\n{shop['payment']}",
        "location": f"📍 *አድራሻ*\n\n{shop['location']}",
        "hours": f"⏰ *የስራ ሰዓት*\n\n{shop['working_hours']}",
        "contact": f"📞 *ያግኙን*\n\nለፈጣን ምላሽ ይህ bot ጋር ይፃፉ!\nወይም admin ቀጥታ ያነጋግሩ 🙏",
        "order": (
            "🛒 *ትዕዛዝ ለማድረግ*\n\n"
            "እባክዎ የሚከተለውን ፎርም ሙሉ 👇\n\n"
            "1️⃣ ስምዎ\n"
            "2️⃣ የሚፈልጉት ምርት\n"
            "3️⃣ ብዛት\n"
            "4️⃣ አድራሻ\n\n"
            "ለምሳሌ: አቤ | ቀሚስ ቀይ | 1 | ቦሌ ቅርብ"
        ),
    }

    # Admin callbacks
    if data == "admin_stats":
        stats = get_stats(1)
        text = (
            f"📊 *Statistics*\n\n"
            f"👥 ደንበኞች: {stats['total_users']}\n"
            f"📦 ትዕዛዞች: {stats['total_orders']}\n"
            f"⏳ Pending: {stats['pending_orders']}\n"
            f"💬 Messages: {stats['total_messages']}"
        )
        await query.edit_message_text(text, parse_mode="Markdown", reply_markup=admin_keyboard())
        return

    if data == "admin_orders":
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("SELECT chat_id, product, status, created_at FROM orders ORDER BY id DESC LIMIT 10")
        rows = c.fetchall()
        conn.close()
        if not rows:
            text = "📋 ምንም ትዕዛዝ እስካሁን የለም"
        else:
            lines = ["📋 *የቅርብ ጊዜ ትዕዛዞች*\n"]
            for r in rows:
                lines.append(f"• Chat: {r[0]} | {r[1][:30]}... | {r[2]} | {r[3][:10]}")
            text = "\n".join(lines)
        await query.edit_message_text(text, parse_mode="Markdown", reply_markup=admin_keyboard())
        return

    if data == "admin_edit":
        text = (
            "✏️ *Shop Info ለማስተካከል*\n\n"
            "ቀጥሎ ካሉት commands ተጠቀም:\n\n"
            "/setname [ስም] - የሱቅ ስም\n"
            "/setprice [ዋጋ ዝርዝር] - ዋጋ\n"
            "/setdelivery [መረጃ] - ማድረሻ\n"
            "/setpayment [ዘዴ] - ክፍያ\n"
            "/setlocation [አድራሻ] - አድራሻ\n"
            "/sethours [ሰዓት] - የስራ ሰዓት"
        )
        await query.edit_message_text(text, parse_mode="Markdown", reply_markup=admin_keyboard())
        return

    if data in responses:
        await query.edit_message_text(
            responses[data],
            parse_mode="Markdown",
            reply_markup=main_keyboard(),
        )


# ─────────────────────────────────────────────
# Admin Commands
# ─────────────────────────────────────────────
def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_LIST


async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("⛔ Admin ብቻ ነው መጠቀም የሚችለው።")
        return
    stats = get_stats(1)
    shop = get_shop(1)
    text = (
        f"👨‍💼 *Admin Panel — {shop['shop_name']}*\n\n"
        f"📊 ስታቲስቲክስ:\n"
        f"  👥 ደንበኞች: {stats['total_users']}\n"
        f"  📦 ትዕዛዞች: {stats['total_orders']}\n"
        f"  ⏳ Pending: {stats['pending_orders']}\n"
        f"  💬 Messages: {stats['total_messages']}\n"
    )
    await update.message.reply_text(text, parse_mode="Markdown", reply_markup=admin_keyboard())


async def set_shop_field(update: Update, context: ContextTypes.DEFAULT_TYPE, field: str):
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("⛔ Admin ብቻ ነው።")
        return
    if not context.args:
        await update.message.reply_text(f"ምሳሌ: /{field.split('_')[0]} [እዚህ ጻፍ]")
        return
    value = " ".join(context.args)
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute(f"UPDATE shops SET {field}=? WHERE id=1", (value,))
    conn.commit()
    conn.close()
    await update.message.reply_text(f"✅ ተዘምኗል: {value}")


async def cmd_setname(u, c): await set_shop_field(u, c, "shop_name")
async def cmd_setprice(u, c): await set_shop_field(u, c, "price_list")
async def cmd_setdelivery(u, c): await set_shop_field(u, c, "delivery_info")
async def cmd_setpayment(u, c): await set_shop_field(u, c, "payment")
async def cmd_setlocation(u, c): await set_shop_field(u, c, "location")
async def cmd_sethours(u, c): await set_shop_field(u, c, "working_hours")


async def broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send a message to all users — admin only"""
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("⛔ Admin ብቻ ነው።")
        return
    if not context.args:
        await update.message.reply_text("ምሳሌ: /broadcast [መልዕክት]")
        return
    message = " ".join(context.args)
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT DISTINCT chat_id FROM users")
    users = c.fetchall()
    conn.close()
    sent, failed = 0, 0
    for (chat_id,) in users:
        try:
            await context.bot.send_message(chat_id=chat_id, text=f"📢 {message}")
            sent += 1
        except Exception:
            failed += 1
    await update.message.reply_text(f"✅ ተልኳል: {sent} | ❌ ያልተሳካ: {failed}")


async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        "🤖 *Roha Bot — Help*\n\n"
        "ለደንበኞች:\n"
        "/start — ቦቱን ጀምር\n\n"
        "ለ Admin:\n"
        "/admin — Admin panel\n"
        "/setname — ሱቅ ስም ቀይር\n"
        "/setprice — ዋጋ ቀይር\n"
        "/setdelivery — ማድረሻ ቀይር\n"
        "/setpayment — ክፍያ ቀይር\n"
        "/setlocation — አድራሻ ቀይር\n"
        "/sethours — ሰዓት ቀይር\n"
        "/broadcast — ለሁሉም ደንበኞች ላክ\n"
    )
    await update.message.reply_text(text, parse_mode="Markdown")


# ─────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────
def main():
    init_db()

    app = Application.builder().token(TELEGRAM_TOKEN).build()

    # User commands
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_cmd))

    # Admin commands
    app.add_handler(CommandHandler("admin", admin_panel))
    app.add_handler(CommandHandler("setname", cmd_setname))
    app.add_handler(CommandHandler("setprice", cmd_setprice))
    app.add_handler(CommandHandler("setdelivery", cmd_setdelivery))
    app.add_handler(CommandHandler("setpayment", cmd_setpayment))
    app.add_handler(CommandHandler("setlocation", cmd_setlocation))
    app.add_handler(CommandHandler("sethours", cmd_sethours))
    app.add_handler(CommandHandler("broadcast", broadcast))

    # Callbacks (inline buttons)
    app.add_handler(CallbackQueryHandler(handle_callback))

    # Messages
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    logger.info("🚀 Roha Bot is live!")
    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
