# 🤖 Roha Bot

Telegram AI chat bot ለሱቆች | Powered by Gemini AI

---

## ⚡ Render ላይ Deploy ማድረጊያ ደረጃዎች

### 1. GitHub ላይ ስቀል (Push)
- GitHub.com ላይ account ፍጠር (ካልሌለህ)
- New repository ፍጠር → "roha-bot" ብለህ ስጠው
- ይህን ፋይሎች upload አድርግ (bot.py, requirements.txt, README.md)

### 2. Render ላይ Deploy
1. render.com ግባ → Sign up (GitHub account ጋር ቀላል ነው)
2. **New** → **Background Worker** ምረጥ (Web Service ሳይሆን!)
3. GitHub repo "roha-bot" አገናኝ
4. Settings:
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `python bot.py`

### 3. Environment Variables (አስፈላጊ!)
Render dashboard → Environment ላይ እነዚህን ጨምር:

| Variable | Value |
|----------|-------|
| TELEGRAM_TOKEN | ከ BotFather ያገኘኸው token |
| GEMINI_API_KEY | ከ Google AI Studio ያገኘኸው key |
| ADMIN_IDS | ያንተ Telegram user ID (ቁጥር) |

### 4. Gemini API Key ማግኘት
1. aistudio.google.com ሂድ
2. Sign in with Google
3. "Get API Key" ተጫን → ነፃ ነው!

### 5. ያንተ Telegram ID ማወቅ
@userinfobot ቴሌግራም ላይ ፈልግ → /start → ID ይሰጥሃል

---

## 🎮 Admin Commands

| Command | ምን ያደርጋል |
|---------|-----------|
| /admin | Admin panel + statistics |
| /setname [ስም] | ሱቅ ስም ቀይር |
| /setprice [ዋጋ] | ዋጋ ዝርዝር ቀይር |
| /setdelivery [info] | ማድረሻ መረጃ ቀይር |
| /setpayment [info] | ክፍያ ዘዴ ቀይር |
| /setlocation [አድራሻ] | አድራሻ ቀይር |
| /sethours [ሰዓት] | የስራ ሰዓት ቀይር |
| /broadcast [message] | ለሁሉም ደንበኞች ላክ |

---

## ✨ Features
- 🤖 Gemini AI powered responses (አማርኛ + እንግሊዝኛ)
- 📋 Inline keyboard buttons (ምርት፣ ዋጋ፣ ትዕዛዝ...)
- 📦 Order tracking (ትዕዛዝ ማዘጋጀት)
- 📊 Admin dashboard (statistics)
- 📢 Broadcast message ለሁሉም ደንበኞች
- 💬 Conversation history (8 messages)
- 👥 User registration
- ✏️ Dynamic shop info update (ያለ code ቀይር)
